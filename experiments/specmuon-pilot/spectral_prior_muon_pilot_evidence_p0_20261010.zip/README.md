# spectral_prior_muon_pilot

Independent pilot project (Task B): can a **spectral prior** on the Muon orthogonalization
step improve training, and does it justify an AdamW transfer candidate later?

This project is **independent of the V16 experiments** (`adamw_spectral_pilot/campaign_v16`).
It never modifies V16 sources, queues, budgets, holdouts, or runners.

## Read-only inputs (never modified)

| Source | Path | Used for |
|---|---|---|
| m1 frozen checkpoints | `muon_transition_experiment/outputs/m1/` | P0-A: real Nesterov momentum matrices |
| Parent restore points | `muon_spectral_allocation/outputs/p0_p1_v1_1/parent/` (seed 3101, steps 512/1536/2048) | P1 pilot restore points |
| v07 AdamW state bank | `legacy_fluctuation_response/outputs/e3_confirmatory/v07/` | P0-B: AdamW m/v states |
| T2a time-series audit | `muon_temporal_response/outputs/t2a_scale_v1/` | P0-C: time-PSD data availability |
| Frozen Muon wheel | torch 2.11.0 `_muon.py`, sha256 `38e95918...` | native NS5 ground truth |
| modded-nanogpt git history | Polar Express coefficient sequence | validated convergent high-step reference |

## Layout

- `docs/` — protocol, hypotheses, deliverable reports
- `src/specmuon/` — spectral operators, optimizer wrapper, P0 analysis scripts
- `tests/` — numerical/math/regression tests (CPU)
- `configs/` — frozen configs (written before the corresponding analysis is run)
- `results/` — new outputs only
- `audits/` — execution ledger and gate decisions

## Resource policy

- CPU-only while any V16 GPU task is alive; threads capped (see configs).
- GPU work only after the GPU gate in `docs/GPU_COST_ESTIMATE.md` is explicitly passed.

## Deliverables

P0 stage: `docs/P0_SPECTRAL_AUDIT.md`, `docs/SPECMUON_OPERATOR_TESTS.md`,
`docs/SPECMUON_FROZEN_PILOT.md`, `docs/BASELINE_SOURCE_AUDIT.md`, `docs/GPU_COST_ESTIMATE.md`.
P1 stage (only if the pilot legally runs): `results/p1/SPECMUON_P1_RESULTS.csv`,
`docs/SPECMUON_P1_DECISION.md`, evidence ZIP.
