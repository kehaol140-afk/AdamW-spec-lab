# PILOT_100M_EVIDENCE_BUNDLE — 复算说明

## 内容

- `runs/run__<arm>.json`：15 臂终点元数据（dev NLL 三视界、wall、吞吐、VRAM、init/final 指纹、tokens_consumed）。
- `runs/eval_docs_H4096__<arm>.jsonl`：逐文档 loss_sum/token_count（256 docs；配对 bootstrap 输入）。
- `metrics/<arm>.jsonl`：全 4096 步逐步原始记录（loss/lr/opt_s/NS5 秒/方向诊断锚点）。
- `analysis.json` / `selection.json`：冻结分析输出与选择步记录。
- `PILOT_100M_RESULTS.csv` / `PILOT_100M_DECISION.md` / `PILOT_100M_RUNTIME.md` / `MOMENTUM_SCALING_ERRATA.md` / `momentum_errata.json`。
- `configs/`：冻结 15 臂 spec、代码冻结哈希（含 runner 修订条目）、缓存铸造清单、v1.1 增补提案（未采纳）。
- `logs/`：driver 日志（并行会话版 + 本会话 driver 两行残留事件）、preflight 100 步诊断。
- `recompute/`：分析与逐文档评价脚本。

## 复算路径（服务器上）

1. 逐文档聚合核对：对任一臂
   `sum(loss_sum)/sum(token_count)` 应等于 `runs/run__<arm>.json` 的 `dev_nll_by_horizon["4096"]`（本包生成时 15/15 偏差 = 0.0）。
2. 配对 bootstrap：`recompute/pilot_analyze.py`（原地路径运行需 `results/pilot/` 目录结构；或将脚本与本包 `runs/`、`analysis.json` 对照参数后运行）。种子 9071、1000 reps、GAIN_THRESHOLD=1e-3 均冻结于脚本内。
3. 逐文档评价复现：`recompute/pilot_eval_docs.py <arm>`（需项目目录 + endpoint_weights.pt；权重文件按纪律不入本包，指纹见 run.json `final_fingerprint`）。

## 身份链

init fingerprint 全臂 `33f93a0f546149a0`；缓存 sha `f92715b4…`（V16 8.5M + s30m 17M 前缀字节证明，见 configs/pilot_cache_manifest.json）；tokenizer `71f32c68…`；代码 = configs/CODE_FREEZE_V1.json（18 文件 + runner 修订条目）。

## 排除项

endpoint_weights.pt（15 × 403 MB，保留于项目 `results/pilot/<arm>/`）；GPU0 训练窗口之外的历史产物（见 100M_PREFLIGHT_EVIDENCE_20261012.zip）。
